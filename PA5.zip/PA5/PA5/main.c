/* 
	Programmer: Liana Wu
	Class: Cpts 121, Lab 3
	Programming Assignment: PA5
	Date: 10/23/2019

	Description: Yahtzee game, a dice game between two players where they 
	strategically select combinations based on their dice rolls
	to get the highest amount of points. 
*/

#include "header.h"

int main(void)
{
	/* Initialize Variables */
	int rounds = 0, player1 = TRUE,
		dice[DICE_NUM] = { 0 },
		p1_score[COMBO_NUM] = { 0 }, p1_combos[COMBO_NUM] = { 0 },
		p2_score[COMBO_NUM] = { 0 }, p2_combos[COMBO_NUM] = { 0 };

	/* Set Random Seed */
	srand((unsigned int)time(NULL));

	/* Game Setup */
	while (menu())
	{
		while (rounds < 13)
		{
			/* PLAYER 1 */
			system("cls");
			printf("***************************** PLAYER 1 ******************************\n");
			printf("***************************** ROUND %d ******************************\n\n", rounds);

			roll_dice(dice);
			display_dice(dice, p1_combos);
			reroll(dice, p1_combos, PLAYER1, rounds);
			select_combo(dice, p1_combos, p1_score, PLAYER1, rounds);

			system("cls");
			printf("***************************** PLAYER 1 ******************************\n");
			printf("***************************** ROUND %d ******************************\n\n", rounds);
			display_score(p1_score, PLAYER1);

			printf("\n\nPress any key to switch to player 2.");
			system("pause > nul");
			system("cls");

			/* PLAYER 2 */
			system("cls");
			printf("***************************** PLAYER 2 ******************************\n");
			printf("***************************** ROUND %d ******************************\n\n", rounds);
			roll_dice(dice);
			display_dice(dice, p2_combos);
			reroll(dice, p1_combos, PLAYER2, rounds);
			select_combo(dice, p2_combos, p2_score, PLAYER2, rounds);

			system("cls");
			printf("***************************** PLAYER 2 ******************************\n");
			printf("***************************** ROUND %d ******************************\n\n", rounds);
			display_score(p2_score, PLAYER2);

			system("pause\n");
			system("cls");

			rounds++;
		}
		game_end(p1_score, p2_score);
	}
	printf("Goodbye!\n\n");
	return 0;
}
