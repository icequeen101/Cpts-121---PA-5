/*
	Programmer: Liana Wu
	Class: Cpts 121, Lab 3
	Programming Assignment: PA5
	Date: 10/23/2019

	Description: Yahtzee game, a dice game between two players where they
	strategically select combinations based on their dice rolls
	to get the highest amount of points.
*/

/* Libraries */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* GAME MENU */
#define RULES 1
#define GAME 2                
#define EXIT 3 

/* BOOLEANS */
#define TRUE 1  
#define FALSE 0

/* PLAYER NUMBERS */
#define PLAYER1 1
#define PLAYER2 2

/* DICE MAX VALUES */
#define DICE_NUM 5
#define DICE_LINES 5
#define MAX_REROLL 2

/* DICE NUMBERS */
#define DICE_ZERO 0
#define DICE_ONE 1
#define DICE_TWO 2
#define DICE_THREE 3
#define DICE_FOUR 4

/* GAME COMBINATIONS */
#define COMBO_NUM 14
#define ONES 1 
#define TWOS 2 
#define THREES 3 
#define FOURS 4 
#define FIVES 5 
#define SIXES 6 
#define THREE_OF_A_KIND 7 
#define FOUR_OF_A_KIND 8 
#define FULL_HOUSE 9 
#define SMALL_STRAIGHT 10 
#define LARGE_STRAIGHT 11 
#define YAHTZEE 12 
#define CHANCE 13

/* BONUS POINTS */
#define BONUS_RANGE 63
#define BONUS_POINTS 35

/* WIN/LOSE */
#define TIE 0
#define P1_WIN 1
#define P2_WIN 2

/* Functions */

/*
	Function: menu()
	Date Created: 10/23/19
	Description: Displays game menu and directs player to
				 specific screen depending on his/her input
	Input Parameters: N/A
	Returns: True/False game continues
	Preconditions: Start of program
	Postconditions: Directs player to specific screen
*/

int menu(void);

/*
	Function: roll_dice()
	Date Created: 10/23/19
	Description: Rolls five dice
	Input Parameters: Dice array
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Update dice array
*/

void roll_dice(int dice_values[DICE_NUM]);

/*
	Function: display_dice()
	Date Created: 10/23/19
	Description: Displays images of the five dice rolls
	Input Parameters: Dice array, combo array
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Display dice images
*/

void display_dice(int dice[DICE_NUM], int combos[COMBO_NUM]);

/*
	Function: reroll()
	Date Created: 10/23/19
-	Description: Asks user if her/she wants to reroll specific
				 dice, and how many. Then, updates dice array.
	Input Parameters: Dice array, combo array, player number,
					  rounds
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Updates dice array
*/

void reroll(int dice[DICE_NUM], int combos[COMBO_NUM], int player_num, int rounds);

/*
	Function: select_combo()
	Date Created: 10/23/19
	Description: Asks user to choose a game combination,
				 checks if the combo has been used
	Input Parameters: Dice array, combo array, scores array,
					  player nummber, and rounds
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Updates combo array
*/

void select_combo(int dice[DICE_NUM], int combos[COMBO_NUM], int scores[COMBO_NUM], int player_num, int rounds);

/*
	Function: display_score()
	Date Created: 10/23/19
	Description: Display's current player's score
	Input Parameters: Combo array, player number
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Display score
*/

void display_score(int scores[COMBO_NUM], int player_num);

/*
	Function: display_combos()
	Date Created: 10/23/19
	Description: Prints game combination choices.
				 If used, number is replaced with X
	Input Parameters: Combo array
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Displays player's avaliable combos
*/

void display_combos(int combos[COMBO_NUM]);

/*
	Function: ones()
	Date Created: 10/23/19
	Description: Add sums of 1's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int ones(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: twos()
	Date Created: 10/23/19
	Description: Add sums of 2's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int twos(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: threes()
	Date Created: 10/23/19
	Description: Add sums of 3's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int threes(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: fours()
	Date Created: 10/23/19
	Description: Add sums of 4's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int fours(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: fives()
	Date Created: 10/23/19
	Description: Add sums of 5's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int fives(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: sixes()
	Date Created: 10/23/19
	Description: Add sums of 6's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int sixes(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: three_of_a_kind()
	Date Created: 10/23/19
	Description: Checks for three-of-a-kind,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int three_of_a_kind(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: four_of_a_kind()
	Date Created: 10/23/19
	Description: Checks for four-of-a-kind,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int four_of_a_kind(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: full_house()
	Date Created: 10/23/19
	Description: Checks for full house,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/


int full_house(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: small_straight()
	Date Created: 10/23/19
	Description: Checks for small straight,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int small_straight(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: large_straight()
	Date Created: 10/23/19
	Description: Checks for large straight,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int large_straight(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: yahtzee()
	Date Created: 10/23/19
	Description: Checks for yahtzee,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int yahtzee(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: chance()
	Date Created: 10/23/19
	Description: Update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int chance(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]);

/*
	Function: game_end()
	Date Created: 10/23/19
	Description: Checks if player qualifies for bonus points;
				 If so, update points array. Calculate and display winners.
	Input Parameters: Player 1 & 2 point arrays
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Display winner
*/

void game_end(int p1_points[COMBO_NUM], int p2_points[COMBO_NUM]);










