/*
	Programmer: Liana Wu
	Class: Cpts 121, Lab 3
	Programming Assignment: PA5
	Date: 10/23/2019

	Description: Yahtzee game, a dice game between two players where they
	strategically select combinations based on their dice rolls
	to get the highest amount of points.
*/

#include "header.h"

/* 
	Function: menu()
	Date Created: 10/23/19
	Description: Displays game menu and directs player to 
				 specific screen depending on his/her input
	Input Parameters: N/A
	Returns: True/False game continues
	Preconditions: Start of program
	Postconditions: Directs player to specific screen
*/

int menu() {
	int player_menu_input = 0, game = FALSE;

	printf("                     Welcome to Yahtzee!                     \n");																// Welcome Screen 													
	printf("*************************************************************\n");
 
	do {
		/* Get Player Menu Choice */
		do {
			printf("                         GAME MENU                         \n");
			printf("Choose an option by entering the corresponding number:\n");
			printf("1. Print game rules\n");
			printf("2. Start a game of Yahtzee\n");
			printf("3. Exit\n");
			scanf("%d", &player_menu_input);
		} while ((player_menu_input != RULES) && (player_menu_input != GAME) && (player_menu_input != EXIT));

		/* Filter Game Options */
		switch (player_menu_input) {
		case RULES:
			system("cls");
			printf("                         Welcome to Yahtzee!                         \n");
			printf("*********************************************************************\n");
			printf("                    WANT TO TEST YOUR LUCK AND SKILL?                \n");
			printf("---------------------------------------------------------------------\n");
			printf("                        THE RULES OF YAHTZEE:                      \n\n");
			printf("The scorecard used for Yahtzee is composed of two sections.   \n");
			printf("A upper section and a lower section.						  \n");
			printf("A total of thirteen boxes or thirteen scoring combinations are\n");
			printf("divided amongst the sections. The upper section consists of   \n");
			printf("boxes that are scored by summing the value of the dice        \n");
			printf("matching the faces of the box. If a player rolls four 3's,    \n");
			printf("then the score placed in the 3's box is the sum of the dice   \n");
			printf("which is 12. Once a player has chosen to score a box, it may  \n");
			printf("not be changed and the combination is no longer in play for   \n");
			printf("future rounds. If the sum of the scores in the upper section  \n");
			printf("is greater than or equal to 63, then 35 more points are       \n");
			printf("added to the players overall score as a bonus. The lower      \n");
			printf("section contains a number of poker like combinations.         \n");
			printf("\n\n");
			printf("                             Table:                           \n");
			printf("Name           | Combination          | Score                   \n");
			printf("3-of-a-kind    | 3 dice w/ same face  | Sum of all values (5 dice)\n");
			printf("4-of-a-kind    | 4 dice w/ same face  | Sum of all values (5 dice)\n");
			printf("Full house     | 1 pair & 3-of-a-kind | 25\n");
			printf("Small straight | Sequence of 4 dice   | 30\n");
			printf("Large straight | Sequence of 5 dice   | 40\n");
			printf("Yahtzee        | 5 dice w/ same face  | 50\n");
			printf("Chance         | Any sequence of dice | Sum of all values (5 dice)\n");
			printf("---------------------------------------------------------------------\n");
			break;
		case GAME:
			game = TRUE;
			break;
		case EXIT:
			game = FALSE;
			break;
		default:
			printf("Enter a valid option.\n");
		}
	} while ((player_menu_input != GAME) && (player_menu_input != EXIT));
	system("cls");

	return game;
}

/*
	Function: roll_dice()
	Date Created: 10/23/19
	Description: Rolls five dice
	Input Parameters: Dice array 
	Returns: N/A
	Preconditions: Start of program 
	Postconditions: Update dice array
*/

void roll_dice(int dice[DICE_NUM]) {
	printf("Press any key to roll the dice.\n\n");
	system("pause > nul");

	for (int i = 0; i < DICE_NUM; i++) {
		dice[i] = (rand() % 6 + 1);
	}
}

/*
	Function: display_dice()
	Date Created: 10/23/19
	Description: Displays images of the five dice rolls
	Input Parameters: Dice array, combo array
	Returns: N/A
	Preconditions: Start of program 
	Postconditions: Display dice images
*/

void display_dice(int dice[DICE_NUM], int combos[COMBO_NUM]) {
	int i = 0, line = 1;

	while (line <= DICE_LINES) {																				// Prints 5 Lines To Create The Dice Image
		switch (line) {																							// Loops through each line at a time
		case 1:
			while (i < DICE_NUM) {																				// Loops through each dice
				switch (dice[i]) {
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
					printf("-----	");
					break;
				}
				i++;
			}
			printf("\n");
			line++;
			i = 0;																								// Reset index
			break;

		case 2:
			while (i < DICE_NUM) {
				switch (dice[i]) {
				case 1:
					printf("|   |	");
					break;
				case 2:
					printf("|o  |	");
					break;
				case 3:
					printf("|o  |	");
					break;
				case 4:
					printf("|o o|	");
					break;
				case 5:
					printf("|o o|	");
					break;
				case 6:
					printf("|o o|	");
					break;
				}
				i++;
			}
			printf("\n");
			line++;
			i = 0;
			break;

		case 3:
			while (i < DICE_NUM) {
				switch (dice[i]) {
				case 1:
					printf("| o |	");
					break;
				case 2:
					printf("|   |	");
					break;
				case 3:
					printf("| o |	");
					break;
				case 4:
					printf("|   |	");
					break;
				case 5:
					printf("| o |	");
					break;
				case 6:
					printf("|o o|	");
					break;
				}
				i++;
			}
			printf("\n");
			line++;
			i = 0;
			break;

		case 4:
			while (i < DICE_NUM) {
				switch (dice[i]) {
				case 1:
					printf("|   |	");
					break;
				case 2:
					printf("|  o|	");
					break;
				case 3:
					printf("|  o|	");
					break;
				case 4:
					printf("|o o|	");
					break;
				case 5:
					printf("|o o|	");
					break;
				case 6:
					printf("|o o|	");
					break;
				}
				i++;
			}
			printf("\n");
			line++;
			i = 0;
			break;

		case 5:
			while (i < DICE_NUM) {
				switch (dice[i]) {
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
					printf("-----	");
					break;
				}
				i++;
			}
			printf("\n\n");
			line++;
			break;
		}
	}
	display_combos(combos);
}

/*
	Function: reroll()
	Date Created: 10/23/19
-	Description: Asks user if her/she wants to reroll specific 
				 dice, and how many. Then, updates dice array.
	Input Parameters: Dice array, combo array, player number, 
					  rounds 
	Returns: N/A
	Preconditions: Start of program 
	Postconditions: Updates dice array
*/

void reroll(int dice[DICE_NUM], int combos[COMBO_NUM], int player_num, int rounds) {
	int num = 0, reroll_index = 0, dice_reroll = 0;

	/* Ask Player - Dice Reroll? */
	for (int i = 0; i < MAX_REROLL; i++) {																								
		do {
			printf("How many dice would you like to reroll? Otherwise, enter 0 to use this roll. ");
			scanf("%d", &num);
		} while ((num != 0) && (num != 1) && (num != 2) && (num != 3) && (num != 4) && (num != 5));

		/* Ask Player - Which Dice To Reroll? */
		if (num != 0) {
			for (reroll_index = 0; reroll_index < num; reroll_index++) {
				do {
					printf("Enter a single dice you would like to reroll (1-5 from left to right): ");
					scanf("%d", &dice_reroll);
					dice[dice_reroll - 1] = rand() % 6 + 1;
				} while ((dice_reroll != 1) && (dice_reroll != 2) && (dice_reroll != 3) && (dice_reroll != 4) && (dice_reroll != 5));
			}
		}
		else {
			break;
		}
		system("cls");
		printf("***************************** PLAYER %d ******************************\n", player_num);
		printf("***************************** ROUND %d ******************************\n\n", rounds);

		display_dice(dice, combos);
	}
}

/*
	Function: select_combo()
	Date Created: 10/23/19
	Description: Asks user to choose a game combination, 
				 checks if the combo has been used
	Input Parameters: Dice array, combo array, scores array, 
					  player nummber, and rounds
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Updates combo array
*/

void select_combo(int dice[DICE_NUM], int combos[COMBO_NUM], int scores[COMBO_NUM], int player_num, int rounds) {
	int player_selection = 0, combo_valid = FALSE;

	system("cls");
	printf("***************************** PLAYER %d ******************************\n", player_num);
	printf("***************************** ROUND %d ******************************\n\n", rounds);
	display_dice(dice, combos);

	/* Player Enters Combination, Repeats If Already Used */
	do {
		printf("Enter a combination: ");
		scanf("%d", &player_selection);

		switch (player_selection) {
		case ONES:
			combo_valid = ones(dice, combos, scores);
			break;
		case TWOS:
			combo_valid = twos(dice, combos, scores);
			break;
		case THREES:
			combo_valid = threes(dice, combos, scores);
			break;
		case FOURS:
			combo_valid = fours(dice, combos, scores);
			break;
		case FIVES:
			combo_valid = fives(dice, combos, scores);
			break;
		case SIXES:
			combo_valid = sixes(dice, combos, scores);
			break;
		case THREE_OF_A_KIND:
			combo_valid = three_of_a_kind(dice, combos, scores);
			break;
		case FOUR_OF_A_KIND:
			combo_valid = four_of_a_kind(dice, combos, scores);
			break;
		case FULL_HOUSE:
			combo_valid = full_house(dice, combos, scores);
			break;
		case SMALL_STRAIGHT:
			combo_valid = small_straight(dice, combos, scores);
			break;
		case LARGE_STRAIGHT:
			combo_valid = large_straight(dice, combos, scores);
			break;
		case YAHTZEE:
			combo_valid = yahtzee(dice, combos, scores);
			break;
		case CHANCE:
			combo_valid = chance(dice, combos, scores);
			break;
		default:
			printf("Please enter a valid option.\n\n");
			break;
		}
	} while (!combo_valid);
}

/*
	Function: display_combos()
	Date Created: 10/23/19
	Description: Prints game combination choices. 
				 If used, number is replaced with X
	Input Parameters: Combo array
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Displays player's avaliable combos
*/

void display_combos(int combos[COMBO_NUM]) {

	/* Prints Combinations; If Used, Prints X */
	if (combos[ONES] == FALSE) {
		printf("1. Sum of 1's\n");
	}
	else {
		printf("X. Sum of 1's\n");
	}

	if (combos[TWOS] == FALSE) {
		printf("2. Sum of 2's\n");
	}
	else { printf("X. Sum of 2's\n"); }

	if (combos[THREES] == FALSE) {
		printf("3. Sum of 3's\n");
	}
	else {
		printf("X. Sum of 3's\n");
	}

	if (combos[FOURS] == FALSE) {
		printf("4. Sum of 4's\n");
	}
	else {
		printf("X. Sum of 4's\n");
	}

	if (combos[FIVES] == FALSE) {
		printf("5. Sum of 5's\n");
	}
	else {
		printf("X. Sum of 5's\n");
	}

	if (combos[SIXES] == FALSE) {
		printf("6. Sum of 6's\n");
	}
	else {
		printf("X. Sum of 6's\n");
	}

	if (combos[THREE_OF_A_KIND] == FALSE) {
		printf("7. Three-of-a-kind\n");
	}
	else {
		printf("X. Three of a kind\n");
	}

	if (combos[FOUR_OF_A_KIND] == FALSE) {
		printf("8. Four-of-a-kind\n");
	}
	else {
		printf("X. Four of a kind\n");
	}

	if (combos[FULL_HOUSE] == FALSE) {
		printf("9. Full house\n");
	}
	else {
		printf("X. Full house\n");
	}

	if (combos[SMALL_STRAIGHT] == FALSE) {
		printf("10. Small Straight\n");
	}
	else {
		printf("X. Small Straight\n");
	}

	if (combos[LARGE_STRAIGHT] == FALSE) {
		printf("11. Large Straight\n");
	}
	else {
		printf("X. Large Straight\n");
	}

	if (combos[YAHTZEE] == FALSE) {
		printf("12. Yahtzee\n");
	}
	else {
		printf("X. Yahtzee\n");
	}

	if (combos[CHANCE] == FALSE) {
		printf("13. Chance\n\n");
	}
	else {
		printf("X. Chance\n\n");
	}
}

/*
	Function: display_score()
	Date Created: 10/23/19
	Description: Display's current player's score
	Input Parameters: Combo array, player number
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Display score
*/

void display_score(int scores[COMBO_NUM], int player_num) {
	int sum = 0;
	for (int i = 1; i < COMBO_NUM; i++) {
		sum += scores[i];
	}
	printf("Player %d's score: %d.\n", player_num, sum);
}

/*
	Function: ones()
	Date Created: 10/23/19
	Description: Add sums of 1's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used 
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int ones(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int sum = 0, used = FALSE;

	if (combos[ONES] == FALSE) {
		combos[ONES] = TRUE;
		used = TRUE;
		for (int i = 0; i < DICE_NUM; i++) {
			if (dice[i] == (ONES)) {
				sum += 1;
			}
		}
		points[ONES] = sum;
	}
	return used;
}

/*
	Function: twos()
	Date Created: 10/23/19
	Description: Add sums of 2's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int twos(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int sum = 0, used = FALSE;

	if (combos[TWOS] == FALSE) {
		combos[TWOS] = TRUE;
		used = TRUE;
		for (int i = 0; i < DICE_NUM; i++) {
			if (dice[i] == TWOS) {
				sum += 1;
			}
		}
		points[TWOS] = sum * TWOS;
	}
	return used;
}

/*
	Function: threes()
	Date Created: 10/23/19
	Description: Add sums of 3's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int threes(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int sum = 0, used = FALSE;

	if (combos[THREES] == FALSE) {
		combos[THREES] = TRUE;
		used = TRUE;
		for (int i = 0; i < DICE_NUM; i++) {
			if (dice[i] == THREES) {
				sum += 1;
			}
		}
		points[THREES] = sum * THREES;
	}
	return used;
}

/*
	Function: fours()
	Date Created: 10/23/19
	Description: Add sums of 4's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int fours(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int sum = 0, used = FALSE;

	if (combos[FOURS] == FALSE) {
		combos[FOURS] = TRUE;
		used = TRUE;
		for (int i = 0; i < DICE_NUM; i++) {
			if (dice[i] == FOURS) {
				sum += 1;
			}
		}
		points[FOURS] = sum * FOURS;
	}
	return used;
}

/*
	Function: fives()
	Date Created: 10/23/19
	Description: Add sums of 5's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int fives(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int sum = 0, used = FALSE;

	if (combos[FIVES] == FALSE) {
		combos[FIVES] = TRUE;
		used = TRUE;
		for (int i = 0; i < DICE_NUM; i++) {
			if (dice[i] == FIVES) {
				sum += 1;
			}
		}
		points[FIVES] = sum * FIVES;
	}
	return used;
}

/*
	Function: sixes()
	Date Created: 10/23/19
	Description: Add sums of 6's, updates points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int sixes(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int sum = 0, used = FALSE;

	if (combos[SIXES] == FALSE) {
		combos[SIXES] = TRUE;
		used = TRUE;
		for (int i = 0; i < DICE_NUM; i++) {
			if (dice[i] == SIXES) {
				sum += 1;
			}
		}
		points[SIXES] = sum * SIXES;
	}
	return used;
}

/*
	Function: three_of_a_kind()
	Date Created: 10/23/19
	Description: Checks for three-of-a-kind,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int three_of_a_kind(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int sum = 0, used = FALSE;

	if (combos[THREE_OF_A_KIND] == FALSE) {																										// Checks If Combo Been Use
		used = TRUE;
		combos[THREE_OF_A_KIND] = TRUE;																											// Sets Combo To Used
		for (int num = 1; num <= 6; num++) {
			sum = 0;
			if (dice[DICE_ZERO] == num) {
				sum += 1;
			}
			if (dice[DICE_ONE] == num) {
				sum += 1;
			}
			if (dice[DICE_TWO] == num) {
				sum += 1;
			}
			if (dice[DICE_THREE] == num) {
				sum += 1;
			}
			if (dice[DICE_FOUR] == num) {
				sum += 1;
			}

			if (sum >= 3) {																														// Three of A Kind
				points[THREE_OF_A_KIND] = dice[DICE_ZERO] + dice[DICE_ONE] + dice[DICE_TWO] + dice[DICE_THREE] + dice[DICE_FOUR];
				break;
			}
		}
	}
	return used;
}

/*
	Function: four_of_a_kind()
	Date Created: 10/23/19
	Description: Checks for four-of-a-kind,
				 update points array 
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int four_of_a_kind(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int sum = 0, used = FALSE;

	if (combos[FOUR_OF_A_KIND] == FALSE) {
		combos[FOUR_OF_A_KIND] = TRUE; 
		for (int num = 1; num <= 6; num++) {
			sum = 0;
			if (dice[DICE_ZERO] == num) {
				sum += 1;
			}
			if (dice[DICE_ONE] == num) {
				sum += 1;
			}
			if (dice[DICE_TWO] == num) {
				sum += 1;
			}
			if (dice[DICE_THREE] == num) {
				sum += 1;
			}
			if (dice[DICE_FOUR] == num) {
				sum += 1;
			}

			if (sum >= 4) {
				points[FOUR_OF_A_KIND] = dice[DICE_ZERO] + dice[DICE_ONE] + dice[DICE_TWO] + dice[DICE_THREE] + dice[DICE_FOUR];
				break;
			}
		}
		used = TRUE;
	}
	return used;
}

/*
	Function: full_house()
	Date Created: 10/23/19
	Description: Checks for full house,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int full_house(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int num1 = 0, num2 = 0, two_kind_sum = 0, three_kind_sum = 0, used = FALSE;

	if (combos[FULL_HOUSE] == FALSE) {
		combos[FULL_HOUSE] = TRUE;
		used = TRUE;

		for (num1 = 1; num1 <= 6; num1++) {																									// Checks For Three Of A Kind
			two_kind_sum = 0;
			if (dice[DICE_ZERO] == num1) {
			three_kind_sum += 1;
			}
			if (dice[DICE_ONE] == num1) {
				three_kind_sum += 1;
			}
			if (dice[DICE_TWO] == num1) {
				three_kind_sum += 1;
			}
			if (dice[DICE_THREE] == num1) {
				three_kind_sum += 1;
			}
			if (dice[DICE_FOUR] == num1) {
				three_kind_sum += 1;
			}
			if (three_kind_sum == 3) {
				break;
			}
		}

		for (num2 = 1; num2 <= 6; num2++) {																								// Checks For Two Of A Kind
			two_kind_sum = 0;
			if (dice[DICE_ZERO] == num2) {
				two_kind_sum += 1;
			}
			if (dice[DICE_ONE] == num2) {
				two_kind_sum += 1;
			}
			if (dice[DICE_TWO] == num2) {
				two_kind_sum += 1;
			}
			if (dice[DICE_THREE] == num2) {
				two_kind_sum += 1;
			}
			if (dice[DICE_FOUR] == num2) {
				two_kind_sum += 1;
			}
			
			if (num2 == num1) {																											// Checks if 2/3 Kind Is Same
				two_kind_sum = 0;
			}
			if (two_kind_sum == 2) {
				if (two_kind_sum + three_kind_sum == DICE_NUM) {
					points[FULL_HOUSE] = 25;
				}
				break;
			}
		}
	}
	return used;
}

/*
	Function: small_straight()
	Date Created: 10/23/19
	Description: Checks for small straight,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int small_straight(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int temp = 0, sum = 0, used = FALSE;

	if (combos[SMALL_STRAIGHT] == FALSE) {																								// Checks If Combo Used
		used = TRUE;
		combos[SMALL_STRAIGHT] = TRUE;
		for (int i = 1; i < DICE_NUM; i++) {																							// Selection Sort		
			for (int j = 0; j < DICE_NUM - i; i++) {
				if (dice[j] > dice[j + 1]) {
					temp = dice[j];
					dice[j] = dice[j + 1];
					dice[j + 1] = temp;
				}
			}
		}

		for (int i = 4; i > 0; i--) {																								 // Check For Small Straight
			if (dice[i] == dice[i - 1] + 1) {
				sum++;
			}
		}

		if (sum >= 3) {																												// Points
			points[SMALL_STRAIGHT] = 30;
		}
	}

	return used;
}

/*
	Function: large_straight()
	Date Created: 10/23/19
	Description: Checks for large straight,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int large_straight(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int temp = 0, sum = 0, used = FALSE;

	if (combos[LARGE_STRAIGHT] == FALSE) {
		used = TRUE;
		combos[LARGE_STRAIGHT] = TRUE;
		for (int i = 1; i < DICE_NUM; i++) {
			for (int j = 0; j < DICE_NUM - i; i++) {
				if (dice[j] > dice[j + 1]) {
					temp = dice[j];
					dice[j] = dice[j + 1];
					dice[j + 1] = temp;
				}
			}
		}

		for (int i = 4; i > 0; i--) {																									// Check For Small Straight
			if (dice[i] == dice[i - 1] + 1) {
				sum++;
			}
		}

		if (sum >= 4) {																													// Points
			points[LARGE_STRAIGHT] = 30;
		}
	}

	return used;
}

/*
	Function: yahtzee()
	Date Created: 10/23/19
	Description: Checks for yahtzee,
				 update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int yahtzee(int dice[DICE_NUM], int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int used = 0, sum = 0;

	if (combos[YAHTZEE] == FALSE) {
		combos[YAHTZEE] = TRUE;
		used = TRUE;

		for (int num = 0; num < DICE_NUM; num++) {
			sum = 0;

			if (dice[DICE_ZERO] == num) {
				sum += 1;
			}
			if (dice[DICE_ONE] == num) {
				sum += 1;
			}
			if (dice[DICE_ONE] == num) {
				sum += 1;
			}
			if (dice[DICE_THREE] == num) {
				sum += 1;
			}
			if (dice[DICE_FOUR] == num) {
				sum += 1;
			}
			if (sum == 5) {
				points[YAHTZEE] = 50;
			}
		}
	}

	return used;
}

/*
	Function: chance()
	Date Created: 10/23/19
	Description: Update points array
	Input Parameters: Dice array, combo array, points array
	Returns: True/False combo is used
	Preconditions: Start of program
	Postconditions: Update points and combo array
*/

int chance(int dice[DICE_NUM],int combos[COMBO_NUM], int points[COMBO_NUM]) {
	int  sum = 0, used = FALSE;

	if (combos[CHANCE] == FALSE) {
		combos[CHANCE] = TRUE;
		used = TRUE;
		sum = dice[DICE_ZERO] + dice[DICE_ONE] + dice[DICE_TWO] + dice[DICE_THREE] + dice[DICE_FOUR];

		points[CHANCE] = sum;
	}

	return used;
}

/*
	Function: game_end()
	Date Created: 10/23/19
	Description: Checks if player qualifies for bonus points;
				 If so, update points array. Calculate and display winners.
	Input Parameters: Player 1 & 2 point arrays
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Display winner
*/

void game_end(int p1_points[COMBO_NUM], int p2_points[COMBO_NUM]) {
	int p1_sum = 0, p2_sum = 0, winner = 0;
	
	printf("***************************** GAME OVER ******************************");


	for (int i = 0; i < DICE_NUM; i++) {
		p1_sum = p1_points[i] + p1_sum;
	}
	for (int i = 0; i < DICE_NUM; i++) {
		p2_sum = p2_points[i] + p2_sum;
	}

	/* Bonus Points */
	if ((p1_points[0] + p1_points[1] + p1_points[2] + p1_points[3] + p1_points[4] + p1_points[5]) > BONUS_RANGE) {
		p1_sum = p1_sum + BONUS_POINTS;
	}
	if ((p2_points[0] + p2_points[1] + p2_points[2] + p2_points[3] + p2_points[4] + p1_points[5]) > BONUS_RANGE) {
		p2_sum = p2_sum + BONUS_POINTS;
	}

	/* Calculate Winner */
	if (p1_sum == p2_sum) {
		winner = TIE;
	}
	if (p1_sum > p2_sum) {
		winner = P1_WIN;
	}
	if (p2_sum > p1_sum) {
		winner = P2_WIN;
	}

	/* Display Winner */
	switch (winner) {
	case TIE:
		printf("It's a tie! Both players have %d points.\n\n", p1_sum);
		break;
	case P1_WIN:
		printf("\n\nPlayer 1 wins with %d points!", p1_sum);
		printf("\nPlayer 2 has %d points.\n\n", p2_sum);
		break;
	case P2_WIN:
		printf("\n\nPlayer 2 wins with %d points!", p2_sum);
		printf("\nPlayer 1 has %d points.\n\n", p1_sum);
		break;
	
	default:
		printf("ERROR");
	}
	system("pause");
	system("cls");
}


